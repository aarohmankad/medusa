# Medusa

Medusa is a Chrome extension that reminds you to periodically look away from your computer screen.

## Inspiration

[How To Keep Computer Screens From Destroying Your Eyes (The Atlantic)](https://www.theatlantic.com/health/archive/2012/09/how-to-keep-computer-screens-from-destroying-your-eyes/263005/)
